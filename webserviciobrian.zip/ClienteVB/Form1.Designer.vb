﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.txtNro1 = New System.Windows.Forms.TextBox()
        Me.txtNro2 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtResultado = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnSuma = New System.Windows.Forms.Button()
        Me.btnResta = New System.Windows.Forms.Button()
        Me.btnMultiplicacion = New System.Windows.Forms.Button()
        Me.btnDivision = New System.Windows.Forms.Button()
        Me.btnPotencia = New System.Windows.Forms.Button()
        Me.btnSen = New System.Windows.Forms.Button()
        Me.btnCos = New System.Windows.Forms.Button()
        Me.btnTan = New System.Windows.Forms.Button()
        Me.btnfac = New System.Windows.Forms.Button()
        Me.btnInversa = New System.Windows.Forms.Button()
        Me.btnLog = New System.Windows.Forms.Button()
        Me.btnPorcentaje = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtNro1
        '
        Me.txtNro1.Location = New System.Drawing.Point(92, 78)
        Me.txtNro1.Name = "txtNro1"
        Me.txtNro1.Size = New System.Drawing.Size(100, 22)
        Me.txtNro1.TabIndex = 0
        '
        'txtNro2
        '
        Me.txtNro2.Location = New System.Drawing.Point(257, 78)
        Me.txtNro2.Name = "txtNro2"
        Me.txtNro2.Size = New System.Drawing.Size(100, 22)
        Me.txtNro2.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(89, 58)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(107, 17)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Ingrese numero"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(254, 58)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(107, 17)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Ingrese numero"
        '
        'txtResultado
        '
        Me.txtResultado.Location = New System.Drawing.Point(218, 319)
        Me.txtResultado.Name = "txtResultado"
        Me.txtResultado.Size = New System.Drawing.Size(100, 22)
        Me.txtResultado.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(214, 275)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 17)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Resultado"
        '
        'btnSuma
        '
        Me.btnSuma.Location = New System.Drawing.Point(51, 132)
        Me.btnSuma.Name = "btnSuma"
        Me.btnSuma.Size = New System.Drawing.Size(75, 23)
        Me.btnSuma.TabIndex = 6
        Me.btnSuma.Text = "+"
        Me.btnSuma.UseVisualStyleBackColor = True
        '
        'btnResta
        '
        Me.btnResta.Location = New System.Drawing.Point(161, 131)
        Me.btnResta.Name = "btnResta"
        Me.btnResta.Size = New System.Drawing.Size(75, 23)
        Me.btnResta.TabIndex = 7
        Me.btnResta.Text = "-"
        Me.btnResta.UseVisualStyleBackColor = True
        '
        'btnMultiplicacion
        '
        Me.btnMultiplicacion.Location = New System.Drawing.Point(268, 132)
        Me.btnMultiplicacion.Name = "btnMultiplicacion"
        Me.btnMultiplicacion.Size = New System.Drawing.Size(75, 23)
        Me.btnMultiplicacion.TabIndex = 8
        Me.btnMultiplicacion.Text = "*"
        Me.btnMultiplicacion.UseVisualStyleBackColor = True
        '
        'btnDivision
        '
        Me.btnDivision.Location = New System.Drawing.Point(370, 131)
        Me.btnDivision.Name = "btnDivision"
        Me.btnDivision.Size = New System.Drawing.Size(75, 23)
        Me.btnDivision.TabIndex = 9
        Me.btnDivision.Text = "/"
        Me.btnDivision.UseVisualStyleBackColor = True
        '
        'btnPotencia
        '
        Me.btnPotencia.Location = New System.Drawing.Point(51, 171)
        Me.btnPotencia.Name = "btnPotencia"
        Me.btnPotencia.Size = New System.Drawing.Size(75, 23)
        Me.btnPotencia.TabIndex = 10
        Me.btnPotencia.Text = "x^n"
        Me.btnPotencia.UseVisualStyleBackColor = True
        '
        'btnSen
        '
        Me.btnSen.Location = New System.Drawing.Point(161, 171)
        Me.btnSen.Name = "btnSen"
        Me.btnSen.Size = New System.Drawing.Size(75, 23)
        Me.btnSen.TabIndex = 11
        Me.btnSen.Text = "Sen"
        Me.btnSen.UseVisualStyleBackColor = True
        '
        'btnCos
        '
        Me.btnCos.Location = New System.Drawing.Point(268, 171)
        Me.btnCos.Name = "btnCos"
        Me.btnCos.Size = New System.Drawing.Size(75, 23)
        Me.btnCos.TabIndex = 12
        Me.btnCos.Text = "Cos"
        Me.btnCos.UseVisualStyleBackColor = True
        '
        'btnTan
        '
        Me.btnTan.Location = New System.Drawing.Point(370, 170)
        Me.btnTan.Name = "btnTan"
        Me.btnTan.Size = New System.Drawing.Size(75, 23)
        Me.btnTan.TabIndex = 13
        Me.btnTan.Text = "Tan"
        Me.btnTan.UseVisualStyleBackColor = True
        '
        'btnfac
        '
        Me.btnfac.Location = New System.Drawing.Point(51, 213)
        Me.btnfac.Name = "btnfac"
        Me.btnfac.Size = New System.Drawing.Size(75, 23)
        Me.btnfac.TabIndex = 14
        Me.btnfac.Text = "!"
        Me.btnfac.UseVisualStyleBackColor = True
        '
        'btnInversa
        '
        Me.btnInversa.Location = New System.Drawing.Point(161, 213)
        Me.btnInversa.Name = "btnInversa"
        Me.btnInversa.Size = New System.Drawing.Size(75, 23)
        Me.btnInversa.TabIndex = 15
        Me.btnInversa.Text = "x^-1"
        Me.btnInversa.UseVisualStyleBackColor = True
        '
        'btnLog
        '
        Me.btnLog.Location = New System.Drawing.Point(268, 213)
        Me.btnLog.Name = "btnLog"
        Me.btnLog.Size = New System.Drawing.Size(75, 23)
        Me.btnLog.TabIndex = 16
        Me.btnLog.Text = "Log"
        Me.btnLog.UseVisualStyleBackColor = True
        '
        'btnPorcentaje
        '
        Me.btnPorcentaje.Location = New System.Drawing.Point(370, 212)
        Me.btnPorcentaje.Name = "btnPorcentaje"
        Me.btnPorcentaje.Size = New System.Drawing.Size(75, 23)
        Me.btnPorcentaje.TabIndex = 17
        Me.btnPorcentaje.Text = "%"
        Me.btnPorcentaje.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(522, 450)
        Me.Controls.Add(Me.btnPorcentaje)
        Me.Controls.Add(Me.btnLog)
        Me.Controls.Add(Me.btnInversa)
        Me.Controls.Add(Me.btnfac)
        Me.Controls.Add(Me.btnTan)
        Me.Controls.Add(Me.btnCos)
        Me.Controls.Add(Me.btnSen)
        Me.Controls.Add(Me.btnPotencia)
        Me.Controls.Add(Me.btnDivision)
        Me.Controls.Add(Me.btnMultiplicacion)
        Me.Controls.Add(Me.btnResta)
        Me.Controls.Add(Me.btnSuma)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtResultado)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtNro2)
        Me.Controls.Add(Me.txtNro1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtNro1 As TextBox
    Friend WithEvents txtNro2 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtResultado As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents btnSuma As Button
    Friend WithEvents btnResta As Button
    Friend WithEvents btnMultiplicacion As Button
    Friend WithEvents btnDivision As Button
    Friend WithEvents btnPotencia As Button
    Friend WithEvents btnSen As Button
    Friend WithEvents btnCos As Button
    Friend WithEvents btnTan As Button
    Friend WithEvents btnfac As Button
    Friend WithEvents btnInversa As Button
    Friend WithEvents btnLog As Button
    Friend WithEvents btnPorcentaje As Button
End Class
