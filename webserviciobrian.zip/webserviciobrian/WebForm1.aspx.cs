﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace webserviciobrian
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            ServiceReference1.WebServicebriSoapClient miservicio = new ServiceReference1.WebServicebriSoapClient();
           double nro1, nro2, suma;
            nro1 = Convert.ToDouble(NRO1.Text);
            nro2 = Convert.ToDouble(NRO2.Text);
            suma = miservicio.Suma(nro1, nro2);
            RESULTADO.Text = Convert.ToString(suma);

           
        }

        protected void resta_Click(object sender, EventArgs e)
        {
            ServiceReference1.WebServicebriSoapClient miservicio = new ServiceReference1.WebServicebriSoapClient();
            double nro1, nro2, resta;
            nro1 = Convert.ToDouble(NRO1.Text);
            nro2 = Convert.ToDouble(NRO2.Text);
            resta = miservicio.Resta(nro1, nro2);
            RESULTADO.Text = Convert.ToString(resta);
        }

        protected void multiplicacion_Click(object sender, EventArgs e)
        {
            ServiceReference1.WebServicebriSoapClient miservicio = new ServiceReference1.WebServicebriSoapClient();
            double nro1, nro2, multiplicacion;
            nro1 = Convert.ToDouble(NRO1.Text);
            nro2 = Convert.ToDouble(NRO2.Text);
            multiplicacion = miservicio.Multiplicacion(nro1, nro2);
            RESULTADO.Text = Convert.ToString(multiplicacion);
        }

        protected void division_Click(object sender, EventArgs e)
        {
            ServiceReference1.WebServicebriSoapClient miservicio = new ServiceReference1.WebServicebriSoapClient();
            double nro1, nro2, division;
            nro1 = Convert.ToDouble(NRO1.Text);
            nro2 = Convert.ToDouble(NRO2.Text);
            division = miservicio.Division(nro1, nro2);
            RESULTADO.Text = Convert.ToString(division);
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            ServiceReference1.WebServicebriSoapClient miservicio = new ServiceReference1.WebServicebriSoapClient();
            int nro1, nro2;
                double potencia;
            nro1 = Convert.ToInt32(NRO1.Text);
            nro2 = Convert.ToInt32(NRO2.Text);
            potencia = miservicio.Potencia(nro1, nro2);
            RESULTADO.Text = Convert.ToString(potencia);
        }

        protected void Sen_Click(object sender, EventArgs e)
        {
            ServiceReference1.WebServicebriSoapClient miservicio = new ServiceReference1.WebServicebriSoapClient();
            int nro1;
                double sen;
            nro1 = Convert.ToInt32(NRO1.Text);
            sen = miservicio.Seno(nro1);
            RESULTADO.Text = Convert.ToString(sen);
        }

        protected void Cos_Click(object sender, EventArgs e)
        {
            ServiceReference1.WebServicebriSoapClient miservicio = new ServiceReference1.WebServicebriSoapClient();
            int nro1;
            double cos;
            nro1 = Convert.ToInt32(NRO1.Text);
           cos = miservicio.Coseno(nro1);
            RESULTADO.Text = Convert.ToString(cos);
        }

        protected void Tang_Click(object sender, EventArgs e)
        {
            ServiceReference1.WebServicebriSoapClient miservicio = new ServiceReference1.WebServicebriSoapClient();
            int nro1;
            double tang;
            nro1 = Convert.ToInt32(NRO1.Text);
            tang = miservicio.Tangente(nro1);
            RESULTADO.Text = Convert.ToString(tang);
        }

        protected void fact_Click(object sender, EventArgs e)
        {
            ServiceReference1.WebServicebriSoapClient miservicio = new ServiceReference1.WebServicebriSoapClient();
            int nro1;
            double fac;
            nro1 = Convert.ToInt32(NRO1.Text);
            fac= miservicio.Factorial(nro1);
            RESULTADO.Text = Convert.ToString(fac);
        }

        protected void inversa_Click(object sender, EventArgs e)
        {
            ServiceReference1.WebServicebriSoapClient miservicio = new ServiceReference1.WebServicebriSoapClient();
            double nro1;
            double inver;
            nro1 = Convert.ToDouble(NRO1.Text);
            inver = miservicio.Inverso(nro1);
            RESULTADO.Text = Convert.ToString(inver);
        }

        protected void LOG_Click(object sender, EventArgs e)
        {
            ServiceReference1.WebServicebriSoapClient miservicio = new ServiceReference1.WebServicebriSoapClient();
            int nro1;
            double LOG;
            nro1 = Convert.ToInt32(NRO1.Text);
            LOG= miservicio.Logaritmo(nro1);
            RESULTADO.Text = Convert.ToString(LOG);
        }

        protected void porcentaje_Click(object sender, EventArgs e)
        {
            ServiceReference1.WebServicebriSoapClient miservicio = new ServiceReference1.WebServicebriSoapClient();
            int nro1, nro2;
            double porcentaje;
            nro1 = Convert.ToInt32(NRO1.Text);
            nro2 = Convert.ToInt32(NRO2.Text);
            porcentaje = miservicio.Porcentaje(nro1, nro2);
            RESULTADO.Text = Convert.ToString(porcentaje);
        }
    }
}